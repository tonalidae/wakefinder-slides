

def suma(a,b):
	"""d\'{o}"""
	# \'{o} ó
	are=a[0]
	aim=a[1]
	bre=b[0]
	bim=b[1]
	return (are+bre,aim+bim)

def multip(a,b):
	are=a[0]
	aim=a[1]
	bre=b[0]
	bim=b[1]
	return (are*bre-aim*bim,aim*bre+bim*are)

def divi(a,b):
	are=a[0]
	aim=a[1]
	bre=b[0]
	bim=b[1]
	return (are*bre+aim*bim)/(bre**2+bim**2),(aim*bre-are*bim)/(bre**2+bim**2)
	
def imp(a):
	"""o"""
	return "{:f}{:+f}i".format(a[0],a[1])

if __name__=="__main__":
	q=(1.,5.)
	w=(3.,4.)
	h=(4.,0)
	
	a=suma(q,w)
	b=multip(q,h)
	c=divi(w,h)
	
	print imp(a)
	print imp(b)
	print imp(c)
