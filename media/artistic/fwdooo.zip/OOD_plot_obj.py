# Programa para calcular la resolución optica y la distancia focal de 
# compensacion para un deflector acusto optico.



from pylab import *






# Caracteristicas de operación del AOD

TA = 15e-6   # Access time S
FM = 140e6   # Center frequency Hz
DF = 40e6    # Bandwidth Hz  
VA = 650.   # Acoustic Velocity m/s
LBD = 405e-9 #Illumination wavelength


class AOD:
	def __init__(self,TA,FM,DF,VA=650.,LBD=405e-9,FS=1e4):
		
		self.TA=TA
		self.FM=FM
		self.DF=DF
		self.VA=VA
		self.LBD=LBD
		self.FS=FS
		
	def TScan(self):
		return 1/self.FS

	
	def TBP(self):
		return self.TA*self.DF
		
	def Nspots(self):
		return self.TBP()*(1-self.TA/(self.TScan()-self.TA))
	
	def THB(self):
		return self.LBD*self.FM/(2*self.VA)


	def SCANG(self):
		return self.LBD*self.DF/self.VA
		
	def Nspots_sec(self):
		return self.Nspots()*self.FS

MR=[]

FF=linspace(1000,33000,100)

myaod=AOD(TA,FM,DF,VA)

for FDS in FF:
	myaod.FS=FDS	
	MR.append(myaod.Nspots_sec())

plot(FF,MR)
show()
