# Programa para calcular la resolución optica y la distancia focal de 
# compensacion para un deflector acusto optico.



# Caracteristicas de operación del AOD

TA = 15e-6   # Access time S
FM = 140e6   # Center frequency Hz
DF = 40e6    # Bandwidth Hz  
VA = 650.   # Acoustic Velocity m/s
LBD = 405e-9 #Illumination wavelength



#Frecuencia de la señal diente de sierra de manejo
FDS = 5000. #Hz

TScan = 1./FDS #tiempo de escaneo

TBP = TA*DF # Time Band Width Product
print("Time Band Width Product (numero de puntos teoricos):", TBP)

Nspots=TBP*(1-TA/(TScan-TA))
print("Numero de puntos utilizable:",Nspots) 

THB = LBD*FM/(2*VA)
print("Angulo de Brag:",THB)

SCANG=LBD*DF/VA
print("Angulo de escaneo:",SCANG)
