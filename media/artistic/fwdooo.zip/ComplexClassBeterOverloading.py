#!/usr/bin/python
# -*- coding: utf8 -*-
"""
Programa para demostrar la creación de una librería con una clase para 
operar números complejos.

ver: 

http://docs.python.org/reference/datamodel.html#emulating-numeric-types
"""

class Complex:
    def __init__(self,re,im=0):
        """Define un numero complejo, donde re contiene la parte
        real e im contiene la parte imaginaria del número.
        """
        self.re=re
        self.im=im
        
    def __add__(self,other):
        """
        Función que calcula la suma de 2 números complejos 
        """
        if isinstance(other,Complex):
            return Complex(self.re+other.re,self.im+other.im)
        elif isinstance(other,(int,float)):
            return Complex(self.re+other,self.im)
        else: return NotImplemented     
    
    def __radd__(self,other):
        """
        Función que calcula la suma de 2 números complejos 
        """
        return self.__add__(other)
    
    def __sub__(self,other):
        """
        Función que calcula la suma de 2 números complejos 
        """
        if isinstance(other,Complex):
            return Complex(self.re-other.re,self.im-other.im)
        elif isinstance(other,(int,float)):
            return Complex(self.re-other.re,self.im)
        else: return NotImplemented     
    
    def __rsub__(self,other):
        return self.__sub__(other)
        
    
    def __neg__(self):
        return Complex(-self.re,-self.im)
    
    def __mul__(self,other):
        """
        Función que calcula el producto de 2 números complejos 
        """
        if isinstance(other,Complex):
            return Complex(self.re*other.re-self.im*other.im,
                           self.im*other.re+other.im*self.re)
        elif isinstance(other,(int,float)):
            return Complex(other*self.re,other*self.im)
        else: return NotImplemented
   
    def __rmul__(self, other):
        return self.__mul__(other)
   
    def __div__(self,other):
        """Función que calcula la divición entre 2 numeros
        complejos self/other"""
        if isinstance(other,Complex):
            return Complex((self.re*other.re+self.im*other.im)/\
                           (other.re**2+other.im**2),
                           (self.im*other.re-self.re*other.im)/\
                           (other.re**2+other.im**2))
        elif isinstance(other,(int,float)):
            return Complex(self.re/other, self.im/other)
        else: return NotImplemented
    
    def __rdiv__(self, other):
        t=Complex(other,0)
        return t/self
        
    def __str__(self):
        """Función que genera una cadena de caracteres con la 
        representación de un número complejo
        """
        return "{:f}{:+f}i".format(self.re,self.im)

if __name__=="__main__":
    q=Complex(1.,5.)
    w=Complex(3.,4.)
    h=Complex(4.)
    
    a=q+w
    a1=a*3
    a3=-w-5*q
    b=q*h
    c=w/h
    
    print a
    print a1
    print b
    print c
