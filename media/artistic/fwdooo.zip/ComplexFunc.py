#!/usr/bin/python
# -*- coding: utf8 -*-
"""
Programa para demostrar la creación de una librería para operar números 
complejos. 
Cada numero complejo se va a definir como una tupla con la parte real y 
la parte imaginaria del número
z=(re,im)
"""

def suma(a,b):
	"""
	Función que calcula la suma de 2 números complejos 
	"""
	are=a[0]
	aim=a[1]
	bre=b[0]
	bim=b[1]
	return (are+bre,aim+bim)

def multip(a,b):
	"""
	Función que calcula el producto de 2 números complejos 
	"""
	are=a[0]
	aim=a[1]
	bre=b[0]
	bim=b[1]
	return (are*bre-aim*bim,aim*bre+bim*are)

def divi(a,b):
	"""Función que calcula la divición entre 2 numeros complejos
	a/b"""
	are=a[0]
	aim=a[1]
	bre=b[0]
	bim=b[1]
	return (are*bre+aim*bim)/(bre**2+bim**2),
	       (aim*bre-are*bim)/(bre**2+bim**2)
	
def imp(a):
	"""Función que genera una cadena de caracteres con la 
	representación de un número complejo
	"""
	return "{:f}{:+f}i".format(a[0],a[1])

if __name__=="__main__":
	q=(1.,5.)
	w=(3.,4.)
	h=(4.,0)
	
	a=suma(q,w)
	b=multip(q,h)
	c=divi(w,h)
	
	print imp(a)
	print imp(b)
	print imp(c)
