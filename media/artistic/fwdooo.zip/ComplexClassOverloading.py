#!/usr/bin/python
# -*- coding: utf8 -*-
"""
Programa para demostrar la creación de una librería con una clase para 
operar números complejos.

ver: 

http://docs.python.org/reference/datamodel.html#emulating-numeric-types
"""

class Complex:
	def __init__(self,re,im=0):
		"""Define un numero complejo, donde re contiene la parte 
		real e im contiene la parte imaginaria del número.
		"""
		self.re=re
		self.im=im
		
	def __add__(self,other):
		"""
		Función que calcula la suma de 2 números complejos 
		"""
		return Complex(self.re+other.re,self.im+other.im)
	
	def __sub__(self,other):
		"""
		Función que calcula la suma de 2 números complejos 
		"""
		return Complex(self.re-other.re,self.im-other.im)
	
	def __neg__(self):
		return Complex(-self.re,-self.im)
	
	def __mul__(self,other):
		"""
		Función que calcula el producto de 2 números complejos 
		"""
		return Complex(self.re*other.re-self.im*other.im,
		               self.im*other.re+other.im*self.re)

	def __div__(self,other):
		"""Función que calcula la divición entre 2 numeros 
		complejos self/other"""
		return Complex((self.re*other.re+self.im*other.im)/\
				       (other.re**2+other.im**2),
		               (self.im*other.re-self.re*other.im)/\
		               (other.re**2+other.im**2))
		
	def __str__(self):
		"""Función que genera una cadena de caracteres con 
		la representación de un número complejo
		"""
		return "{:f}{:+f}i".format(self.re,self.im)

if __name__=="__main__":
	q=Complex(1.,5.)
	w=Complex(3.,4.)
	h=Complex(4.)
	
	a=q+w
	a1=q-w
	a3=-w
	b=q*h
	c=w/h
	
	print a
	print a1
	print b
	print c
