#!/usr/bin/python
# -*- coding: utf8 -*-
"""
Programa para demostrar la creación de una librería con una clase para 
operar números complejos.
"""

class Complex:
	def __init__(self,re,im=0):
		"""Define un numero complejo, donde re contiene la parte
		real e im contiene la parte imaginaria del número.
		"""
		self.re=re
		self.im=im
		
	def suma(self,other):
		"""
		Función que calcula la suma de 2 números complejos 
		"""
		return Complex(self.re+other.re,self.im+other.im)

	def multip(self,other):
		"""
		Función que calcula el producto de 2 números complejos 
		"""
		return Complex(self.re*other.re-self.im*other.im,
		               self.im*other.re+other.im*self.re)

	def divi(self,other):
		"""Función que calcula la divición entre 2 numeros 
		complejos self/other"""
		return Complex((self.re*other.re+self.im*other.im)/\
					   (other.re**2+other.im**2),
		               (self.im*other.re-self.re*other.im)/\
		               (other.re**2+other.im**2))
		
	def imp(self):
		"""Función que genera una cadena de caracteres con la representación 
		de un número complejo
		"""
		return "{:f}{:+f}i".format(self.re,self.im)

if __name__=="__main__":
	q=Complex(1.,5.)
	w=Complex(3.,4.)
	h=Complex(4.)
	
	a=q.suma(w)
	b=q.multip(h)
	c=w.divi(h)
	
	print a.imp()
	print b.imp()
	print c.imp()
